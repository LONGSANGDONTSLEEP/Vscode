#pragma once

#include <stdbool.h>
#include "esp_err.h"
#include "driver/gpio.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    gpio_num_t gpio_clk;
    gpio_num_t gpio_cmd;
    gpio_num_t gpio_d0;
    gpio_num_t gpio_d1;
    gpio_num_t gpio_d2;
    gpio_num_t gpio_d3;

    const char *mount_point;        // 默认 "/sdcard"
    int max_files;                  // 默认 5
    bool format_if_mount_failed;    // 第一版建议 false，避免误格式化 SD 卡
    bool use_4bit;                  // true: 4-bit, false: 1-bit
} sd_card_mgr_config_t;

esp_err_t sd_card_mgr_init_sdmmc(const sd_card_mgr_config_t *cfg);
esp_err_t sd_card_mgr_deinit(void);

bool sd_card_mgr_is_mounted(void);
const char *sd_card_mgr_mount_point(void);

esp_err_t sd_card_mgr_write_test_file(void);

#ifdef __cplusplus
}
#endif