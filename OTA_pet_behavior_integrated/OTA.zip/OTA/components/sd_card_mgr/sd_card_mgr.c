#include "sd_card_mgr.h"

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

#include "esp_check.h"
#include "esp_log.h"
#include "esp_vfs_fat.h"
#include "driver/sdmmc_host.h"
#include "sdmmc_cmd.h"

#define TAG "SD_CARD"

static sdmmc_card_t *s_card = NULL;
static bool s_mounted = false;
static char s_mount_point[32] = "/sdcard";

esp_err_t sd_card_mgr_init_sdmmc(const sd_card_mgr_config_t *cfg)
{
    ESP_RETURN_ON_FALSE(cfg, ESP_ERR_INVALID_ARG, TAG, "cfg is NULL");

    if (s_mounted) {
        ESP_LOGW(TAG, "SD card already mounted");
        return ESP_OK;
    }

    const char *mount_point = cfg->mount_point ? cfg->mount_point : "/sdcard";
    snprintf(s_mount_point, sizeof(s_mount_point), "%s", mount_point);

    ESP_LOGI(TAG, "Initializing SD card in SDMMC mode");
    ESP_LOGI(TAG, "CLK=%d CMD=%d D0=%d D1=%d D2=%d D3=%d",
             cfg->gpio_clk,
             cfg->gpio_cmd,
             cfg->gpio_d0,
             cfg->gpio_d1,
             cfg->gpio_d2,
             cfg->gpio_d3);

    esp_vfs_fat_sdmmc_mount_config_t mount_config = {
        .format_if_mount_failed = cfg->format_if_mount_failed,
        .max_files = cfg->max_files > 0 ? cfg->max_files : 5,
        .allocation_unit_size = 16 * 1024,
    };

    sdmmc_host_t host = SDMMC_HOST_DEFAULT();

    /*
     * 先用默认 20MHz，不要一开始开 40MHz。
     * SD 卡记录宠物状态不需要高速，稳定优先。
     */
    host.max_freq_khz = SDMMC_FREQ_DEFAULT;

    sdmmc_slot_config_t slot_config = SDMMC_SLOT_CONFIG_DEFAULT();

    /*
     * 你的硬件接线：
     * SD2  -> GPIO6
     * SD3  -> GPIO7
     * CMD  -> GPIO15
     * CLK  -> GPIO16
     * SD0  -> GPIO18
     * SD1  -> GPIO8
     */
    slot_config.clk = cfg->gpio_clk;
    slot_config.cmd = cfg->gpio_cmd;
    slot_config.d0  = cfg->gpio_d0;
    slot_config.d1  = cfg->gpio_d1;
    slot_config.d2  = cfg->gpio_d2;
    slot_config.d3  = cfg->gpio_d3;

    /*
     * 4-bit 模式：CLK/CMD/D0/D1/D2/D3 都参与。
     * 1-bit 模式：只用 CLK/CMD/D0，适合排查问题。
     */
    slot_config.width = cfg->use_4bit ? 4 : 1;

    /*
     * 内部上拉只能用于调试，正式硬件最好有外部上拉。
     */
    slot_config.flags |= SDMMC_SLOT_FLAG_INTERNAL_PULLUP;

    esp_err_t ret = esp_vfs_fat_sdmmc_mount(
        s_mount_point,
        &host,
        &slot_config,
        &mount_config,
        &s_card
    );

    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "SD card mount failed: %s", esp_err_to_name(ret));

        if (ret == ESP_FAIL) {
            ESP_LOGE(TAG, "Failed to mount filesystem. "
                          "If you want to format the card, set format_if_mount_failed = true.");
        } else if (ret == ESP_ERR_TIMEOUT) {
            ESP_LOGE(TAG, "SD card timeout. Check wiring, pull-ups, power supply, and card.");
        } else {
            ESP_LOGE(TAG, "SD card init failed. Check GPIO mapping and SD card format.");
        }

        return ret;
    }

    s_mounted = true;

    ESP_LOGI(TAG, "SD card mounted at %s", s_mount_point);
    sdmmc_card_print_info(stdout, s_card);

    return ESP_OK;
}

esp_err_t sd_card_mgr_deinit(void)
{
    if (!s_mounted) {
        return ESP_OK;
    }

    esp_err_t ret = esp_vfs_fat_sdcard_unmount(s_mount_point, s_card);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "SD card unmount failed: %s", esp_err_to_name(ret));
    }

    s_card = NULL;
    s_mounted = false;

    ESP_LOGI(TAG, "SD card unmounted");
    return ret;
}

bool sd_card_mgr_is_mounted(void)
{
    return s_mounted;
}

const char *sd_card_mgr_mount_point(void)
{
    return s_mount_point;
}

esp_err_t sd_card_mgr_write_test_file(void)
{
    ESP_RETURN_ON_FALSE(s_mounted, ESP_ERR_INVALID_STATE, TAG, "SD card not mounted");

    char path[64];
    snprintf(path, sizeof(path), "%s/test.txt", s_mount_point);

    ESP_LOGI(TAG, "Writing test file: %s", path);

    FILE *f = fopen(path, "a");
    if (f == NULL) {
        ESP_LOGE(TAG, "Failed to open file for writing: %s", path);
        return ESP_FAIL;
    }

    fprintf(f, "hello sd card, pet collar test\n");
    fclose(f);

    ESP_LOGI(TAG, "Test file written");
    return ESP_OK;
}