#include "hwinit.h"

#include "gpio_drv.h"
#include "i2c_bus.h"
#include "led_ctrl.h"
#include "pwrkeep.h"
#include "sd_card_mgr.h"

#include "esp_err.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define TAG "HW_INIT"

static i2c_master_bus_handle_t s_i2c_bus;

void check_stack(void)
{
    ESP_LOGI("Stack", "Main task stack high water mark: %u", (unsigned)uxTaskGetStackHighWaterMark(NULL));
}

i2c_master_bus_handle_t hwinit_get_i2c_bus(void)
{
    return s_i2c_bus;
}

static void sd_card_init(void)
{
    ESP_LOGI(TAG, "SD card init start");

    /*
     * SDMMC 4-bit 接线：
     * SD2  -> GPIO6
     * SD3  -> GPIO7
     * CMD  -> GPIO15
     * CLK  -> GPIO16
     * SD0  -> GPIO18
     * SD1  -> GPIO8
     */
    sd_card_mgr_config_t sd_cfg = {
        .gpio_clk = GPIO_NUM_16,
        .gpio_cmd = GPIO_NUM_15,
        .gpio_d0  = GPIO_NUM_18,
        .gpio_d1  = GPIO_NUM_8,
        .gpio_d2  = GPIO_NUM_6,
        .gpio_d3  = GPIO_NUM_7,

        .mount_point = "/sdcard",
        .max_files = 5,
        .format_if_mount_failed = false,
        .use_4bit = true,
    };

    esp_err_t ret = sd_card_mgr_init_sdmmc(&sd_cfg);
    if (ret == ESP_OK) {
        ESP_LOGI(TAG, "SD card init success");
        sd_card_mgr_write_test_file();
    } else {
        ESP_LOGW(TAG, "SD card init failed: %s", esp_err_to_name(ret));
    }
}

void hw_init(void)
{
    ESP_LOGI(TAG, "Hardware init start");
    check_stack();

    ESP_LOGI(TAG, "PWRKEEP init start");
    esp_err_t pk_err = pwrkeep_init();
    if (pk_err != ESP_OK) {
        ESP_LOGE(TAG, "pwrkeep_init failed: %s", esp_err_to_name(pk_err));
    } else {
        ESP_LOGI(TAG, "PWRKEEP 初始化完成");
    }

    ESP_LOGI(TAG, "GPIO init start");
    ESP_ERROR_CHECK(gpio_drv_init());
    ESP_LOGI(TAG, "GPIO 初始化完成");
    check_stack();

    ESP_LOGI(TAG, "I2C init start");
    ESP_ERROR_CHECK(i2c_bus_init(&s_i2c_bus, I2C_NUM_0, 13, 12, 400000));
    ESP_LOGI(TAG, "I2C 初始化完成");
    check_stack();

    /*
     * SD 卡属于硬件初始化，放在 hw_init 里。
     * SD 初始化失败不影响主程序继续运行。
     */
    sd_card_init();
    check_stack();

    led_ctrl_demo_start();

    ESP_LOGI(TAG, "Hardware init done");
}